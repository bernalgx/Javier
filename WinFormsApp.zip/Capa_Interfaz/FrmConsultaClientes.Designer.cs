﻿//namespace Capa_Interfaz
//{
//    partial class FrmConsultaClientes
//    {
//        /// <summary>
//        /// Required designer variable.
//        /// </summary>
//        private System.ComponentModel.IContainer components = null;

//        /// <summary>
//        /// Clean up any resources being used.
//        /// </summary>
//        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
//        protected override void Dispose(bool disposing)
//        {
//            if (disposing && (components != null))
//            {
//                components.Dispose();
//            }
//            base.Dispose(disposing);
//        }

//        #region Windows Form Designer generated code

//        /// <summary>
//        /// Required method for Designer support - do not modify
//        /// the contents of this method with the code editor.
//        /// </summary>
//        private void InitializeComponent()
//        {
//            dgvClientes = new DataGridView();
//            Clientes = new DataGridViewTextBoxColumn();
//            btnCargarDatos = new Button();
//            ((System.ComponentModel.ISupportInitialize)dgvClientes).BeginInit();
//            SuspendLayout();
//            // 
//            // dgvClientes
//            // 
//            dgvClientes.AllowUserToOrderColumns = true;
//            dgvClientes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
//            dgvClientes.Columns.AddRange(new DataGridViewColumn[] { Clientes });
//            dgvClientes.Location = new Point(109, 12);
//            dgvClientes.Name = "dgvClientes";
//            dgvClientes.Size = new Size(597, 150);
//            dgvClientes.TabIndex = 0;
//            // 
//            // Clientes
//            // 
//            Clientes.HeaderText = "Clientes";
//            Clientes.Name = "Clientes";
//            // 
//            // btnCargarDatos
//            // 
//            btnCargarDatos.Location = new Point(316, 244);
//            btnCargarDatos.Name = "btnCargarDatos";
//            btnCargarDatos.Size = new Size(160, 85);
//            btnCargarDatos.TabIndex = 1;
//            btnCargarDatos.Text = "Cargar Datos";
//            btnCargarDatos.UseVisualStyleBackColor = true;
//            btnCargarDatos.Click += btnCargarDatos_Click;
//            // 
//            // FrmConsultaClientes
//            // 
//            AutoScaleDimensions = new SizeF(7F, 15F);
//            AutoScaleMode = AutoScaleMode.Font;
//            ClientSize = new Size(767, 385);
//            Controls.Add(btnCargarDatos);
//            Controls.Add(dgvClientes);
//            Name = "FrmConsultaClientes";
//            Text = "FrmConsultaClientes";
//            ((System.ComponentModel.ISupportInitialize)dgvClientes).EndInit();
//            ResumeLayout(false);
//        }

//        #endregion

//        private DataGridView dgvClientes;
//        private DataGridViewTextBoxColumn Clientes;
//        private Button btnCargarDatos;
//    }
//}