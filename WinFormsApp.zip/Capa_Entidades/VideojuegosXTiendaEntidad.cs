﻿//TODO NUEVO///////////////


//namespace Capa_Entidades
//{
//    public class VideojuegosXTiendaEntidad
//    {
//        public TiendaEntidad Tienda { get; set; }
//        public VideojuegoEntidad Videojuego { get; set; }
//        public int Existencias { get; set; }
//    }
//}
