﻿//TODO NUEVO///////////

//namespace Capa_Entidades
//{
//    public class ReservaEntidad
//    {
//        public int IdReserva { get; set; }
//        public VideojuegosXTiendaEntidad VideojuegoTienda { get; set; }
//        public ClienteEntidad Cliente { get; set; }
//        public DateTime FechaReserva { get; set; }
//        public int Cantidad { get; set; }

//        public ReservaEntidad(int id, VideojuegosXTiendaEntidad videojuego, ClienteEntidad cliente, DateTime fecha, int cantidad)
//        {
//            IdReserva = id;
//            VideojuegoTienda = videojuego;
//            Cliente = cliente;
//            FechaReserva = fecha;
//            Cantidad = cantidad;
//        }
//    }
//}
