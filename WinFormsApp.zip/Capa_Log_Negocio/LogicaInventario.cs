﻿namespace Capa_Log_Negocio // Define el espacio de nombres para la logica de negocio
{
    internal class LogicaInventario // Clase vacia que representaria la logica relacionada con el inventario
    {
    }
}
